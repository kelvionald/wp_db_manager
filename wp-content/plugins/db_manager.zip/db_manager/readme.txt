=== Database manager ===
Contributors: kelvionald
Tags: database, db, manager, query
Requires at least: 5.2
Tested up to: 5.2.2
Stable tag: 1.0
License: GPLv2 or later

== Description ==

Database manager is simple plug-in ещ view database tables and edit records. It allows you:

* Navigate by menu
* See database records
* Editing of records
* Execute any database query

== Installation ==

Upload the Database manager plugin to your blog, Activate it and use it.

== Changelog ==

= 1.0 =
*Release Date - 15 August 2019*

* Add menu
* Add tables/table view
* Add query view
* Add editing of records