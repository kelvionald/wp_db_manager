<?php

return [
  'menu.title' => 'DB Manager',

  'db.tables_header' => 'Tables',
  'db.table_count'  => 'Rows',
  'db.table_header' => 'Table',
  'db.table_empty' => 'The table is empty.',

  'db.sql_query' => 'SQL query',
  'db.sql_query_submit' => 'Run'
];