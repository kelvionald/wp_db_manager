<?php

return [
  'menu.title' => 'Менеджер БД',

  'db.tables_header' => 'Таблицы',
  'db.table_count'  => 'Строки',
  'db.table_header' => 'Таблица',
  'db.table_empty' => 'Таблица пуста.',

  'db.sql_query' => 'SQL запрос',
  'db.sql_query_submit' => 'Выполнить'
];